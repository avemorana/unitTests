<html>
<head>
    <title>Tests</title>
</head>
<body>
<h3></h3>
<form name="user" action="" method="post">
    <input type="text" name="login">

</form>
</body>
</html>